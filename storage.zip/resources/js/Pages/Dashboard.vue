<script setup>
import SvgLoading from '@/Components/SvgLoading.vue'
import AuthenticatedLayout from '@/Layouts/AuthenticatedLayout.vue'
import { Head, useForm } from '@inertiajs/vue3'
import axios from 'axios'
import { onMounted, ref, watch } from 'vue'

const axiosIns = axios.create({
    baseURL: 'https://api.dongvanfb.net/',
})

axiosIns.interceptors.request.use(
    (config) => {
        isLoading.value = true
        return config
    },
    (error) => {
        isLoading.value = false
        return Promise.reject(error)
    },
)

axiosIns.interceptors.response.use(
    (response) => {
        isLoading.value = false
        return response
    },
    (error) => {
        isLoading.value = false
        return Promise.reject(error)
    },
)

const EMPTY = 0
const SUCCESS = 1
const ERROR = 2

const props = defineProps({
    api_key: {
        type: String,
        required: true,
    },
})

const form = useForm({
    api_key: props.api_key,
})

const listMail = ref([])
const accountTypes = ref([])
const accountType = ref(null)
const apiKeyStatus = ref(EMPTY)
const isKeyChange = ref(false)
const isLoading = ref(false)

onMounted(async () => {
    if (form.api_key.length > 0) {
        apiKeyStatus.value = (await checkBalance()) ? SUCCESS : ERROR
    }

    fetchAccountType()
})

const checkBalance = async () => {
    try {
        const { data } = await axiosIns.get('user/balance?apikey=' + form.api_key)

        return data.status
    } catch (error) {
        return false
    }
}

const applyKey = async () => {
    const status = await checkBalance()

    if (status) {
        form.post(route('apply_key'), {
            onSuccess: () => {
                apiKeyStatus.value = SUCCESS
                isKeyChange.value = false
            },
        })
    } else {
        apiKeyStatus.value = ERROR
    }
}

const fetchAccountType = async () => {
    try {
        const { data } = await axiosIns.get('user/account_type?apikey=' + form.api_key)

        if (data.status) {
            accountTypes.value = data.data.filter((item) => item.quality > 0)
        }
    } catch (error) {
        accountTypes.value = []
    }
}

const buyMail = async () => {
    alert('chưa xong cha ơi')
    // try {
    //     const { data } = await axiosIns.get('user/buy?apikey=' + form.api_key)
    // } catch (error) {}
}

watch(
    () => form.api_key,
    (v) => {
        if (v != props.api_key) {
            isKeyChange.value = true
        } else {
            isKeyChange.value = false

            if (props.api_key.length) {
                apiKeyStatus.value = SUCCESS
            }
        }
        isKeyChange.value = v != props.api_key
    },
)
</script>

<template>
    <Head title="Dashboard" />

    <AuthenticatedLayout>
        <template #header>
            <h2 class="text-xl font-semibold leading-tight text-gray-800 dark:text-gray-200">
                Dashboard
            </h2>
        </template>

        <div class="py-12">
            <div class="mx-auto max-w-7xl sm:px-6 lg:px-8">
                <div class="overflow-hidden bg-white shadow-sm sm:rounded-lg dark:bg-gray-800">
                    <div class="p-6 text-gray-900 dark:text-gray-100">
                        <div class="relative overflow-x-auto shadow-md sm:rounded-lg">
                            <div class="w-100 mb-3 md:w-1/2">
                                <div class="relative">
                                    <input
                                        v-model="form.api_key"
                                        class="block w-full rounded-lg border border-gray-300 bg-gray-50 p-3 ps-4 text-sm text-gray-900 focus:shadow-none focus:outline-none focus:ring-0 dark:border-gray-600 dark:bg-gray-700 dark:text-white dark:placeholder-gray-400"
                                        :class="{
                                            'border-green-500 focus:border-green-500 dark:border-green-500 focus:dark:border-green-500':
                                                apiKeyStatus == SUCCESS && !isKeyChange,
                                            'border-red-500 dark:border-red-500':
                                                apiKeyStatus == ERROR,
                                        }"
                                        placeholder="API Key"
                                    />
                                    <button
                                        class="absolute bottom-2.5 end-2.5 rounded-lg bg-blue-700 px-4 py-1 text-sm font-medium text-white hover:bg-blue-800 focus:outline-none focus:ring-4 focus:ring-blue-300 dark:bg-blue-600 dark:hover:bg-blue-700 dark:focus:ring-blue-800"
                                        :class="{
                                            'cursor-not-allowed opacity-50':
                                                !isKeyChange || isLoading,
                                        }"
                                        :disabled="!isKeyChange || isLoading"
                                        type="button"
                                        @click="applyKey"
                                    >
                                        <SvgLoading v-show="isLoading" />
                                        <span v-show="!isLoading">Apply</span>
                                    </button>
                                </div>
                            </div>
                            <div>
                                <select
                                    v-model="accountType"
                                    class="inline-block w-2/3 rounded-lg border border-gray-300 bg-gray-50 p-2.5 text-sm text-gray-900 focus:border-blue-500 focus:ring-blue-500 md:w-1/3 dark:border-gray-600 dark:bg-gray-700 dark:text-white dark:placeholder-gray-400 dark:focus:border-blue-500 dark:focus:ring-blue-500"
                                >
                                    <option :value="null">Chọn loại Mail</option>
                                    <option
                                        v-for="item in accountTypes"
                                        :key="item.id"
                                        :value="item.id"
                                    >
                                        {{ item.name }} - {{ item.price }}đ
                                    </option>
                                </select>

                                <button
                                    class="mb-2 me-2 ml-2 rounded-lg bg-green-700 px-5 py-3 text-sm font-medium text-white hover:bg-green-800 focus:outline-none focus:ring-4 focus:ring-green-300 dark:bg-green-600 dark:hover:bg-green-700 dark:focus:ring-green-800"
                                    :class="{
                                        'cursor-not-allowed opacity-50':
                                            apiKeyStatus != SUCCESS || isLoading || !accountType,
                                    }"
                                    :disabled="apiKeyStatus != SUCCESS || isLoading || !accountType"
                                    type="button"
                                    @click="buyMail"
                                >
                                    <SvgLoading v-show="isLoading" />
                                    <span v-show="!isLoading">Mua Mail</span>
                                </button>
                            </div>

                            <table
                                class="w-full text-center text-sm text-gray-500 rtl:text-right dark:text-gray-400"
                            >
                                <thead
                                    class="bg-gray-50 text-xs uppercase text-gray-700 dark:bg-gray-700 dark:text-gray-400"
                                >
                                    <tr>
                                        <th
                                            class="px-6 py-3"
                                            scope="col"
                                        >
                                            Email
                                        </th>
                                        <th
                                            class="px-6 py-3"
                                            scope="col"
                                        >
                                            Facebook Code
                                        </th>
                                        <th
                                            class="px-6 py-3"
                                            scope="col"
                                        >
                                            Mail|Password
                                        </th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr
                                        class="border-b border-gray-200 bg-white hover:bg-gray-50 dark:border-gray-700 dark:bg-gray-800 dark:hover:bg-gray-600"
                                    >
                                        <th
                                            class="whitespace-nowrap px-6 py-4 font-medium text-gray-900 dark:text-white"
                                            scope="row"
                                        >
                                            ahihi@gmail.com
                                        </th>
                                        <td class="px-6 py-4">123456</td>
                                        <td class="px-6 py-4">
                                            <button
                                                class="mb-2 me-2 rounded-lg bg-blue-700 px-5 py-1.5 text-sm font-medium text-white hover:bg-blue-800 focus:outline-none focus:ring-4 focus:ring-blue-300 dark:bg-blue-600 dark:hover:bg-blue-700 dark:focus:ring-blue-800"
                                            >
                                                <span id="default-message">Copy</span>
                                                <span
                                                    id="success-message"
                                                    class="hidden"
                                                >
                                                    <div class="inline-flex items-center">
                                                        <svg
                                                            aria-hidden="true"
                                                            class="me-1.5 h-3 w-3 text-white"
                                                            fill="none"
                                                            viewBox="0 0 16 12"
                                                            xmlns="http://www.w3.org/2000/svg"
                                                        >
                                                            <path
                                                                d="M1 5.917 5.724 10.5 15 1.5"
                                                                stroke="currentColor"
                                                                stroke-linecap="round"
                                                                stroke-linejoin="round"
                                                                stroke-width="2"
                                                            />
                                                        </svg>
                                                        Copied!
                                                    </div>
                                                </span>
                                            </button>
                                        </td>
                                    </tr>
                                </tbody>
                            </table>
                            <!-- <nav
                                aria-label="Table navigation"
                                class="flex-column flex flex-wrap items-center justify-between pt-4 md:flex-row"
                            >
                                <span
                                    class="mb-4 block w-full text-sm font-normal text-gray-500 md:mb-0 md:inline md:w-auto dark:text-gray-400"
                                >
                                    Showing
                                    <span class="font-semibold text-gray-900 dark:text-white">
                                        1-10
                                    </span>
                                    of
                                    <span class="font-semibold text-gray-900 dark:text-white">
                                        1000
                                    </span>
                                </span>
                                <ul class="inline-flex h-8 -space-x-px text-sm rtl:space-x-reverse">
                                    <li>
                                        <a
                                            class="ms-0 flex h-8 items-center justify-center rounded-s-lg border border-gray-300 bg-white px-3 leading-tight text-gray-500 hover:bg-gray-100 hover:text-gray-700 dark:border-gray-700 dark:bg-gray-800 dark:text-gray-400 dark:hover:bg-gray-700 dark:hover:text-white"
                                            href="#"
                                        >
                                            Previous
                                        </a>
                                    </li>
                                    <li>
                                        <a
                                            class="flex h-8 items-center justify-center border border-gray-300 bg-white px-3 leading-tight text-gray-500 hover:bg-gray-100 hover:text-gray-700 dark:border-gray-700 dark:bg-gray-800 dark:text-gray-400 dark:hover:bg-gray-700 dark:hover:text-white"
                                            href="#"
                                        >
                                            1
                                        </a>
                                    </li>
                                    <li>
                                        <a
                                            class="flex h-8 items-center justify-center border border-gray-300 bg-white px-3 leading-tight text-gray-500 hover:bg-gray-100 hover:text-gray-700 dark:border-gray-700 dark:bg-gray-800 dark:text-gray-400 dark:hover:bg-gray-700 dark:hover:text-white"
                                            href="#"
                                        >
                                            2
                                        </a>
                                    </li>
                                    <li>
                                        <a
                                            aria-current="page"
                                            class="flex h-8 items-center justify-center border border-gray-300 bg-blue-50 px-3 text-blue-600 hover:bg-blue-100 hover:text-blue-700 dark:border-gray-700 dark:bg-gray-700 dark:text-white"
                                            href="#"
                                        >
                                            3
                                        </a>
                                    </li>
                                    <li>
                                        <a
                                            class="flex h-8 items-center justify-center border border-gray-300 bg-white px-3 leading-tight text-gray-500 hover:bg-gray-100 hover:text-gray-700 dark:border-gray-700 dark:bg-gray-800 dark:text-gray-400 dark:hover:bg-gray-700 dark:hover:text-white"
                                            href="#"
                                        >
                                            4
                                        </a>
                                    </li>
                                    <li>
                                        <a
                                            class="flex h-8 items-center justify-center border border-gray-300 bg-white px-3 leading-tight text-gray-500 hover:bg-gray-100 hover:text-gray-700 dark:border-gray-700 dark:bg-gray-800 dark:text-gray-400 dark:hover:bg-gray-700 dark:hover:text-white"
                                            href="#"
                                        >
                                            5
                                        </a>
                                    </li>
                                    <li>
                                        <a
                                            class="flex h-8 items-center justify-center rounded-e-lg border border-gray-300 bg-white px-3 leading-tight text-gray-500 hover:bg-gray-100 hover:text-gray-700 dark:border-gray-700 dark:bg-gray-800 dark:text-gray-400 dark:hover:bg-gray-700 dark:hover:text-white"
                                            href="#"
                                        >
                                            Next
                                        </a>
                                    </li>
                                </ul>
                            </nav> -->
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </AuthenticatedLayout>
</template>
