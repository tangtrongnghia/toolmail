PHP 8.3.7 (cli) (built: May  8 2024 08:56:34) (NTS Visual C++ 2019 x64)
Copyright (c) The PHP Group
Zend Engine v4.3.7, Copyright (c) Zend Technologies


node -v
v20.11.1
